# Session archive

Generated 2026-10-11T20:03:56.779Z from session `01a12166-4e34-7019-8b73-be8734657cce`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

95 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (38)

- `AbundantGull` — 280 entries, 868003 bytes
- `AccusedPeafowl` — 238 entries, 790846 bytes
- `AggressiveHare` — 183 entries, 507098 bytes
- `AutomaticCrawdad` — 262 entries, 1019222 bytes
- `ComingErmine` — 500 entries, 1602925 bytes
- `CorporateKoi` — 523 entries, 2367883 bytes
- `CriminalWren` — 727 entries, 1983959 bytes
- `DeepDonkey` — 169 entries, 812332 bytes
- `DemocraticPossum` — 506 entries, 1115338 bytes
- `DizzyArmadillo` — 342 entries, 988074 bytes
- `ExceptionalConstrictor` — 454 entries, 1330331 bytes
- `HarshVole` — 135 entries, 382354 bytes
- `HostilePony` — 585 entries, 2547684 bytes
- `HostilePony/HostilePony.PortDequant` — 154 entries, 793437 bytes
- `HostilePony/HostilePony.PortResampler` — 288 entries, 993756 bytes
- `HostilePony/HostilePony.PortXform` — 311 entries, 1203578 bytes
- `HushedPheasant` — 493 entries, 1490171 bytes
- `LinearDamselfly` — 278 entries, 834020 bytes
- `MagicGiraffe` — 635 entries, 2396752 bytes
- `MiniatureParakeet` — 120 entries, 490676 bytes
- `OccupationalGazelle` — 411 entries, 1428821 bytes
- `OtherMarten` — 318 entries, 1017219 bytes
- `RelievedCondor` — 559 entries, 1926056 bytes
- `RidiculousMarlin` — 213 entries, 874797 bytes
- `RidiculousMarlin/RidiculousMarlin.DequantPort` — 75 entries, 293965 bytes (killed)
- `RidiculousMarlin/RidiculousMarlin.GainPostPort` — 68 entries, 287710 bytes (killed)
- `RidiculousMarlin/RidiculousMarlin.SetupPort` — 124 entries, 417880 bytes (killed)
- `RidiculousMarlin/RidiculousMarlin.XformPort` — 68 entries, 335543 bytes (killed)
- `ScreechingBovid` — 607 entries, 1729503 bytes
- `SensitiveBasilisk` — 745 entries, 2738849 bytes
- `SteadyJay` — 709 entries, 2035582 bytes
- `TroubledSailfish` — 207 entries, 818135 bytes
- `YouthfulShark` — 568 entries, 2153789 bytes
- `YouthfulShark/YouthfulShark.CertValidate` — 172 entries, 788569 bytes
- `YouthfulShark/YouthfulShark.DiskFormats` — 159 entries, 621806 bytes
- `YouthfulShark/YouthfulShark.FrontEndTrace` — 218 entries, 1377313 bytes
- `YouthfulShark/YouthfulShark.MarksProducer` — 163 entries, 691371 bytes
- `YouthfulShark/YouthfulShark.VoiceStructs` — 190 entries, 857088 bytes

## Totals

175 files, 115572956 bytes.
