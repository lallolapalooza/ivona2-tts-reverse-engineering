{
  "status": "complete",
  "summary": "The pipeline's unit search is now the engine's search: transcribed FUN_0005fc04's candidate build filter, 51-bucket cost-threshold beam with context exemptions, the two candidate flag bytes, the chunked relaxation with tb_min_distance boundaries (FUN_00030214), and wired it into EngineSelector. Unit-id sequences now match the engine exactly on all three captures (19/19, 26/26, 25/25 = 70/70), and every intermediate the engine exposes matches too.",
  "deliverables": {
    "scripts/select_units.py": "rewritten: build_candidates (+'-context skip, 0x4fd88), threshold (51-bucket sweep, 0x502e0..0x5036c), prune (exemptions via the phone table bytes +3/+5 vs ctx slots 0x08/0x10, disables on pau sides, sets +4/+5 with the node-index guards; whole block skipped when count <= 51), search (node-0 prologue, per-node sort-by-target/total:=target/sort-by-total, transition 0x4fe88 with npred=min(prev,beam) unless +5, joint continuation, budget=e.total-base, beam_arr short-circuit, chunk boundary 0x5055c), Candidate/Node. beam_prune and the old 'N cheapest' select() removed.",
    "refimpl/engine_prosody.py": "selection section rewritten: EngineSelector(..., tb_min_distance=6), .phone_name(), .forced_nodes() (plug-in rule 0x20384..0x204bc, incl. the 1.5*tb compare and the remaining-distance test), .lattice(pairs, ctxs) = engine candidate build (filter + target cost + join variant + forced flag), .select() calls select_units.search and keeps diag keys n_cand/target/join_variants/chosen/cost/n_cand_used (+kept/chunks/forced). Fixed a real off-by-one: the join function for the transition into node i is node i-1's +0xc4 (join_fn_for(ctxs[i])), not node i's.",
    "refimpl/tts.py": "one line: EngineSelector(..., tb_min_distance=cfg['tb_min_distance']).",
    "scripts/probe_viterbi.py": "new: runs the unmodified engine under Unicorn with a basic-block hook over FUN_0005fc04 and dumps every candidate-array mutation (pre-prune/post-prune/post-transition, with target, both flags, total, raw record bytes) + node contexts and +0xc8 flags to out/oracle/viterbi_probe{,_2}/.",
    "scripts/check_viterbi.py": "new: 'rule' replays select_units against those dumps using the ENGINE's own target costs; 'pipeline' runs our EngineSelector and compares kept sets/totals/flags and the unit sequence.",
    "out/viterbi_disasm.txt, out/plugin_graph_disasm.txt": "capstone disassembly of FUN_0005fc04 (ELF 0x4fc04..0x50b08) and of the plug-in's FUN_00030214 flag block.",
    "out/oracle/viterbi_probe/, viterbi_probe2/": "instrumented engine captures (probe2 adds forced snapshots); both reproduce the oracle PCM byte-for-byte (38 783 frames).",
    "out/tts_demo/beam_search.wav, beam_search_default.wav": "pipeline outputs with the new search.",
    "reports": "report_pipeline.md new section 12 (rule table with addresses/constants, staged acceptance, residual, files, supersedes note for 10.2/10.4/11.3); REPLICATION_STATUS.md section 4 causes 1-2 replaced by the measured result, stage rows updated."
  },
  "measured": {
    "kept sets (ids, order, both flag bytes) vs instrumented engine": "19/19 nodes exact ('rule' mode, engine target costs)",
    "per-candidate accumulated totals after the transition": "19/19 nodes exact",
    "candidate build filter (slice -> pre-prune set)": "19/19 nodes exact",
    "pipeline with our own costs/contexts/flags": "kept counts [87,25,119,82,54,116,105,159,131,477,494,123,257,210,253,199,392,623,268] and ids+totals 19/19 exact",
    "unit id sequence": "ref_nopunct 19/19, ref_default 26/26, ref_lexclean 25/25 (70/70); was 3/19, 5/25",
    "chunk boundaries": "node 10 forced (the only one) -> engine 2 calls, ours 2 chunks (11 + 8 units)",
    "target cost (peer harness)": "21 152/21 152 exact over the three captures",
    "audio ref_nopunct": "39 834 vs 38 783 samples = +47.66 ms; envelope corr 0.6412; +/-3 dB 50.6%; lag -220 ms (stop-gap: +97.5..100.1 ms, 0.42-0.44, 31.2%, -240 ms)",
    "audio ref_default": "53 085 vs 53 649 = -25.58 ms; corr 0.6300; +/-3 dB 47.7%; lag +20 ms",
    "splice layer": "--verify-engine still bit-exact for the chain (43 357 samples, 0 diffs)"
  },
  "reproduce": [
    "~/venvs/re/bin/python scripts/probe_viterbi.py --out-dir out/oracle/viterbi_probe2   # ~14 min",
    "~/venvs/re/bin/python scripts/check_viterbi.py rule --probe out/oracle/viterbi_probe2",
    "~/venvs/re/bin/python scripts/check_viterbi.py pipeline --probe out/oracle/viterbi_probe2",
    "~/venvs/re/bin/python scripts/compare_selection.py --oracle-dir out/oracle/ref_nopunct --text \"Hello world this is a test\" --beam 25",
    "~/venvs/re/bin/python scripts/compare_costs.py --oracle-dir out/oracle/ref_nopunct --text \"Hello world this is a test\" --beam 25",
    "~/venvs/re/bin/python refimpl/tts.py --text \"Hello world this is a test\" --out out/tts_demo/beam_search.wav && ~/venvs/re/bin/python scripts/compare_tts.py out/oracle/ref_nopunct/kendra_hello.wav out/tts_demo/beam_search.wav",
    "~/venvs/re/bin/python refimpl/tts.py --text \"Hello world, this is a test.\" --out out/tts_demo/beam_search_default.wav && ~/venvs/re/bin/python scripts/compare_tts.py out/oracle/ref_default/kendra_hello.wav out/tts_demo/beam_search_default.wav"
  ],
  "isolated_residual": {
    "cause": "waveform-stage per-unit duration/window handling (NOT the search)",
    "evidence": "with the chain identical: engine unit durations sum to 2050 ms, engine PCM 1759 ms, our committed stream 1806 ms (43 357 @24k, crossfade drop 120 ms); ref_default goes the other way (-25.58 ms) so it is not a systematic offset; the chain re-spliced through the real .so is bit-exact.",
    "next_step": "[INFERENCE] re-capture FUN_00062d14/FUN_00063540 arguments as doubles (r0:r1 / d0) - out/oracle/*/prosody_transforms.tsv read r1 and recorded 0 / 7e-45 - then apply the per-unit stretch.",
    "known_limits": "the harness re-implements qsort with the library comparators in Python (stable), so ties in the two per-node sorts follow the harness; all comparisons are against captures produced by the same harness. The FUN_00054380 'not greater' semantics in the tb_min_distance rule is inferred (only reading that yields the observed single forced node)."
  },
  "notes_for_main": [
    "report_prosody.md section 6's description of the beam ('smallest threshold under which <=51 candidates remain and drops the rest') and its 'scripts/select_units.py reimplements this search / from select_units import select' snippet, plus section 18's Viterbi row ('not diffed against the engine'), are now stale - I am not allowed to edit that report; a one-line pointer to report_pipeline.md section 12 would fix it.",
    "report_pipeline.md section 10.2's 'beam pruning' and 'unit sequence' rows and section 10.4's causes 4-5 are superseded (noted in my section 12); section 11.3's 'being rewired' note is done and its A/B columns need a re-run - ScreechingBovid owns that subsection and has my numbers.",
    "peer coordination: SteadyJay's 4-line stop-gap in engine_prosody.py is replaced by the real API (they were told); ScreechingBovid was told the rewire landed with the numbers so they can refresh report_pipeline section 11.3 / REPLICATION_STATUS section 4's audio columns."
  ]
}