{
  "status": "delivered-with-open-causes",
  "acceptance_target": "out/oracle/ref_nopunct/ — \"Hello world this is a test\" (38 783 frames = 1.7589 s @ 22 050 Hz)",
  "what_was_wired": {
    "duration_model": "refimpl/engine_prosody.ProsodyModel.durations(): zdur_cart CART (prosody.Cart) evaluated per phoneme + FUN_00048400 pause rules (pause_base_len = 0 from settings.txt). Features supplied exactly: name/p.name/n.name/pp,nn,n,p phone names and all ph_* classes (from the plug-in static phoneset), pos_in_syl, syl_final, syl_break, syl_vowel, syl_in, pos_in_word, pos_in_phrase, stress, position_type, p.seg_onsetcoda; approximated: gpos (closed-class word list — no POS tagger ships), glottal_stop_pos, ssyl_*, accent (only tested against 0).",
    "duration_validation": "byte-identical to the engine's context slot 0x00 for ALL segments: 20/20 (ref_nopunct), 26/26 (ref_lexclean). Two bugs fixed en route: CART leaf division must truncate toward zero (floor was 1 ms low on negative leaves) and pause_base_len is 0, not 0.35.",
    "unit_selection": "lattice = section A/B slices (counts and b_start identical to candidate_lattice.txt; the engine's own candidate sets are exact subsets, 0 extra units); target cost = prosody.dispatch_cost (FUN_00031234) over candidate vectors from the new FUN_0005f1dc port and my FUN_00060ed4 context vectors; join cost = the five FUN_00030xxx variants, dispatched from the node's right-edge context (decompiled FUN_00030214); search = prosody.Viterbi/select_units with the decompiled beam rule.",
    "vector_fields": "Candidate side byte-exact (new scripts/diphone_vec.py, verified against the engine under Unicorn: 3000/3000 records, and against the engine's own candidate_records.tsv). Context side: all numeric slots of FUN_00060ed4 reproduced (syllables from a maximal-onset syllabifier, phrase/word/pos slot semantics fitted to the dump) except 0x26/0x27 ssyl_from/ssyl_to; the 7 resolved string slots match."
  },
  "acceptance_numbers": {
    "chain": "IDENTICAL — 19/19 diphone names + diphoneset_num (pau hh ax l ow w er l d dh ih s ih z ax t eh s t pau)",
    "unit_ids": "3/19 exact (incl. the consecutive run 107796,107797,107798 = the 'test' token); 5/25 exact for ref_lexclean when driven with the engine's own phoneme chain",
    "target_cost_vs_engine_dump": "5630/5630 = 100% exact for interior nodes 1..23 (with the engine's ssyl values supplied); 42% over all 5945 rows without them; the only misses are the two edge nodes",
    "beam_counts": "decompiled rule reproduces the engine's kept counts exactly for 6/25 nodes, within a few % for most others",
    "duration_ms": "+100.1 ms (+5.7%) — mine 40 991 samples / 1.8590 s vs engine 38 783 / 1.7589 s",
    "compare_tts": "envelope_correlation 0.4375; frames_within_3dB 31.2%; best_lag −240 ms; duration_delta_ms 100.14; not bit-exact (different units chosen — the splice layer stays bit-exact for a given chain, 0 diffs via --verify-engine)"
  },
  "isolated_causes_of_divergence": [
    "(1) first/last-node target costs: my recomputation is a constant ~5–6 points below the engine's dump for every candidate at those two nodes, yet FUN_00031234 called under Unicorn with the reconstructed vectors returns exactly my value — so the engine scores the edge nodes with inputs the capture does not expose. A per-node constant cannot reorder within a node; it only shifts join budgets.",
    "(2) ssyl_from/ssyl_to (context 0x26/0x27): engine rule not recovered (they are not the stressed-syllable counts; 0x24/0x25 are and match). ±2 points/candidate; supplying the engine's values takes interior-node cost agreement from 42% to 100%.",
    "(3) beam: my CLI path keeps only the N cheapest candidates (25) whereas the engine's histogram rule + context-name exemptions + tb_min_distance=6 forced flags keep 60–500. Largest single cause of the different chain.",
    "(4) search structure: the engine calls FUN_0005fc04 once per chunk (2 calls here, state[6] persists) and beam-prunes accumulated totals; the pipeline runs one plain DP.",
    "(5) gpos: no tagger ships; the engine's own tagging is context-dependent (this→det in one capture, content in the other).",
    "(6) front end: the engine speaks punctuation by name (comma/dot); my pipeline pauses instead, so comparisons were run on the punctuation-free sentence (and on 'hello comma this is a comma dot dot' to reproduce its chain).",
    "(7) codec: still the emulated decoder + Hamming-sinc resampler; scripts/codec_spec.py (finished by a sibling) can drop into the single Codec.decode_window call site."
  ],
  "voice_params_that_supersede_docs": {
    "viterbi_beam": 25,
    "tb_min_distance": 6,
    "pause_base_len": 0,
    "note": "out/oracle/*/settings.txt is authoritative: report_prosody.md §1.7's 'tb_min_distance unset for Kendra' and the '50/25 fallback' reading are superseded (flagged in the report)."
  },
  "harness_caveat_reported": "out/oracle/*/unit_sequence.txt diphone_dur_ms/cum_ms reads the 36-byte record at the *diphone name index*, not at the selected unit (same values across runs whose units differ: record[1175]=70 ms vs the chosen pau-hh unit's 450 ms). Use unit_feature_vectors.tsv slot 0x00 for durations. Notified CriminalWren.",
  "files": [
    "new: refimpl/engine_prosody.py, scripts/phoneset.py, scripts/diphone_vec.py, scripts/probe_record_vec.py, scripts/compare_selection.py, scripts/compare_costs.py",
    "changed: refimpl/tts.py (--select viterbi default, --beam, CART durations, prosody diagnostics/JSON), scripts/prosody.py (type-tolerant CART question, truncating leaf division, pause_duration(base=…))",
    "outputs: out/engine_match/ (WAV + JSON), out/oracle/clean_they/ (my own capture), report_pipeline.md §10, REPLICATION_HANDBOOK.md §6",
    "reverted: an experimental lex_decode.py syllable API (the blob's 'syllable' table is a phone-fragment pool, not a syllabification) — file left as it was apart from one comment"
  ],
  "reproduce": [
    "~/venvs/re/bin/python scripts/probe_record_vec.py --n 3000",
    "~/venvs/re/bin/python scripts/compare_costs.py --oracle-dir out/oracle/ref_lexclean --text \"hello comma this is a comma dot dot\"",
    "~/venvs/re/bin/python scripts/compare_selection.py --oracle-dir out/oracle/ref_nopunct --text \"hello world this is a test\"",
    "~/venvs/re/bin/python refimpl/tts.py --text \"hello world this is a test\" --out out/engine_match/nopunct_mine.wav --align",
    "~/venvs/re/bin/python scripts/compare_tts.py out/oracle/ref_nopunct/kendra_hello.wav out/engine_match/nopunct_mine.wav"
  ],
  "verified": "no build/test/lint runs were needed beyond the probes above (all executed by me and quoted); every number in report_pipeline.md §10 comes from a command listed there"
}