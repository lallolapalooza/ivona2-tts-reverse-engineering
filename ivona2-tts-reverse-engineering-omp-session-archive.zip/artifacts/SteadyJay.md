{
  "status": "complete (final)",
  "post_rewire_verification": "After CorporateKoi replaced my stop-gap with the engine-exact search (select_units build_candidates/threshold/prune/search + EngineSelector rewire, their report_pipeline.md §12), all of my validations were re-run on the current files and still pass: target cost 6146/6146 (ref_nopunct), 5945/5945 (ref_lexclean), 9061/9061 (ref_default) = 21 152/21 152 with |d| = 0/0/0 everywhere (the first node is now 174/174, previously 0/174); validate_gpos.py 20/20 segments; validate_ssyl.py ALL OK (56/56 bytes over 28 syllables).",
  "final_state_of_my_deliverables": {
    "ssyl_from/ssyl_to": "recovered rule implemented (refimpl/engine_prosody.ssyl_distance -> slots 0x26/0x27), byte-exact on 3 captures.",
    "gpos": "recovered closed-class dictionary (scripts/gpos_table.py) wired into engine_prosody.gpos_of (slots 0x30/0x38/0x40); case-folded, verified with out/oracle/gpos_case/ ('That' -> in); 73/73 segments over three captures.",
    "edge_nodes": "explained and fixed: the pau items' 0x28/0x38 carry the nil string \"0\"; every first/last-node candidate now matches.",
    "reports": "report_cost_terms_main.md new §4d (a/b/c) + status note; report_pipeline.md §10.2 rows and §10.4 items 1-3 rewritten as recovered with evidence, items 4-5 marked closed with a pointer to §12, §10.2's beam/unit-sequence rows flagged as superseded by §12, §10.5 file list extended.",
    "tools": "scripts/gpos_table.py, validate_gpos.py, validate_ssyl.py, analyze_feature_vectors.py, probe_gpos.py, probe_edge_nodes.py (new); compare_selection.py fixed (entry-time zero rows, 0x54/0x58/0x5c string slots); compare_costs.py: the diagnostic DP's join index corrected to join_fn_for(ctxs[i]) and relabelled 'no prune/flags, diagnostic only'.",
    "tooling_note_for_main": "If you re-run the acceptance commands, use scripts/compare_costs.py for the target-cost table (TOTAL should read 6146/6146, 5945/5945, 9061/9061) and ignore its trailing diagnostic Viterbi line (6/19 is expected - it keeps all candidates and applies no prune/flags); the engine-exact selection numbers live in report_pipeline.md §12."
  },
  "residuals": [
    "glottal_stop_pos (0x1b/0x1e/0x2d) still modelled as 0.",
    "Front end (our G2P/LTS + punctuation handling) and the codec remain the only open pipeline differences; the costs, the candidate lattice and the search are now all exact."
  ]
}