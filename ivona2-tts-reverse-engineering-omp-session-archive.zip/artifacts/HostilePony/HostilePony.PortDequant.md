{
  "status": "success",
  "command": "cd scripts/codec_parts && ~/venvs/re/bin/python dequant.py",
  "output": "dequant: vectors=55 byte-identical=55 failed=0",
  "files": "scripts/codec_parts/dequant.py (new; exposes dequant(ctx, frame_info, samp, coeffs) + _selftest())"
}