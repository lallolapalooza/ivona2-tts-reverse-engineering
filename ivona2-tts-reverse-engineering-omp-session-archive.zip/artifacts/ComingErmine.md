{
  "report": "/home/user/Downloads/ivona_re/report_libvoice.md",
  "size_bytes": 44747,
  "lines": 713,
  "sections": [
    "0 address conventions/method",
    "1 register_voice/unregister_voice + interface struct + ABI version",
    "2 data payload (ELF/CDXV/vox file/.rodata map/tables)",
    "3 Kendra vs Amy",
    "4 recipe for a compatible plug-in",
    "5 not determined / what was tried"
  ],
  "key_findings": {
    "address_map": "Ghidra dump image base = 0x10000: file offset = ghidra_addr - 0x10000 (verified on register_voice, '22v', '36', '%d', engine 'name'); file offset == link VMA for all allocated sections",
    "exports": "register_voice@@TTS_ENGINE_1_6 @0x168a0 (56 B), unregister_voice@@TTS_ENGINE_1_6 @0x1689c (4 B, single `b 0x20008`); ABS symbol TTS_ENGINE_1_6 is dynsym #50; versym index 2 applied to #21/#50/#65; engine uses plain dlsym so the real gate is strcmp(eng_version,\"1.6.23\")",
    "signature": "void *register_voice(const char *vox_path) -> 12-byte object {listA@0, listB@4, 0@8}; r0 passes through untouched into FUN_00030020 (capstone-verified); void unregister_voice(void*) frees both lists + object (FUN_00044410)",
    "variants": "list node = 12 B {key*, variant*, next*}; variant = 8 B {u16 tag, pad, payload*}; known tags 0x1F diphonedb, 0x1B lexicon; type-name run at .rodata 0x56A0C-0x56B78; {name,code} registry at .data.rel.ro 0x2EFB90-0x2EFCFC",
    "cdxv": "exactly 3 occurrences, all .text ARM literal-pool words of 0x56584443 at 0x17CD0 (FUN_00027bd0), 0x18004 (FUN_00027f90), 0x182E0 (FUN_00028008); NO CDXV container is embedded in the .so (no header image, no diphone records: b'aa-aa' 0 hits) - the container is an external vox file",
    "vox_header": "0x68 B: magic 'CDXV', char name[32], u32 sample_rate(+0x24), u32 format(+0x28, supported 2/8/12/14), u32 checksum(+0x2C), 7x (off,len) section pairs; shipped 152 MB OBB matches name=vox_en_us_kendra, 22050, 14, 1333557784; path built as <dir>/<name>/<checksum>/<name>22v",
    "rodata_map": "0x28D3D8 total split into 9 sub-regions with sizes: shared strings 0x569B0-0x60428; word/phoneme string tables -0x64BFC; en_US packed lexicon 0x64BFC..0x1CBA5C (0x166E60 B, header {count=0x1EE0C, len}); pool substrings; en_US LTS FSM 0x1CC088 + 27-u32 letter table 0x1EDA48; en_GB lexicon 0x1F2CBC..0x2AE0BC (0xBB400, {count=0xF126}); en_GB pool/FSM 0x2AE434/letter 0x2CEC48; tail numeric tables 0x2D0000-0x2E3D88; entropy 5.25-7.58, no >=4 KiB ASCII runs",
    "dictionary_format": "entries 0xFF-delimited, key = 0x00-terminated u8 indices into a 256-slot string pool, leading flag char skipped by strcmp, variable tail = pronunciation [INFERENCE]; decoded 126,462 sorted en_US entries ('0\\'cause' ... '0zwilling') matching count field 126,476",
    "lts": "6-byte FSM records {u8 input_pos, u8 ch, u16 next_if, u16 next_else}, terminator 0xFF; letter table = 27 ascending u32 (108 B, ends exactly where phone names begin)",
    "kendra_vs_amy": "libttsivonavoice.so/libtiver.so byte-identical between packages; .text same size/layout: 3,894 differing bytes (1.48%), no run >3 B, 386/495 Ghidra functions byte-identical, differences are pc-relative address constants and table sizes; per-voice literals: vox_en_us_kendra/1333557784/en-US/Kendra/36 vs vox_en_gb_amy/1334671314/en-GB/Amy/37; .rodata +0x960 B and .data.rel.ro +0xEC0 B in kendra, content shifted 0x2464 (e.g. _epsilon_ 0x1CBA5C vs 0x1C95F8); both binaries bundle both en_US and en_GB datasets selected at runtime"
  },
  "not_determined": [
    "exact pronunciation-code encoding after each lexicon key",
    "variant tag<->name mapping beyond 0x1F/0x1B",
    "which code re-opens the vox file for record reads (FUN_00027bd0 keeps FILE* but has no call site)",
    "how the Android app passes the vox path to register_voice (OBB path vs extracted <name>22v copy)",
    "meaning of the format/codec ids (only 2,8,12,14 accepted)"
  ],
  "checks_for_main": [
    "read ivona_re/report_libvoice.md end-to-end (713 lines) for agent-facing completeness",
    "python3 scripts/06_rodata_map.py out/libs/kendra/libvoice_en_us_kendra.so 0x10000  # reproduces the entropy table",
    "python3 scripts/08_refs.py out/ghidra_dump/libvoice_kendra.c kendra  # reproduces .rodata reference clustering",
    "md5sum out/libs/{kendra,amy}/libvoice_en_us_kendra.so  # 446e4028eb7cb47f0abc18597a2d8106 / 361f44ba1a84430a29a0a0e8c1396b02 (unchanged, read-only respected)"
  ],
  "files_written": [
    "ivona_re/report_libvoice.md",
    "ivona_re/scripts/06_rodata_map.py",
    "ivona_re/scripts/08_refs.py"
  ],
  "binaries_modified": false
}