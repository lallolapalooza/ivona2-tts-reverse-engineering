{
  "status": "solved",
  "summary": "The main OBB 'gap' payload is decoded and reproduced to PCM/WAV for both shipped voices. It is NOT encrypted: it is one continuous stream of u16le-length-prefixed packets protected by a self-keyed XOR obfuscation whose key is derived from the public header checksum + the packet's own tail bytes. The de-obfuscated packets are decoded by a proprietary fixed-point MDCT/Huffman codec embedded in libttsivonavoice.so, reproduced by emulating the exact engine code path.",
  "key_findings": {
    "correct_decode_path": "OBB header+0x28 = 14 -> FUN_0005f49c switch case 0xe -> init FUN_00067f94, decode LAB_00067db8 (ELF 0x57db8). FUN_000685c4 (ELF 0x685c4) is the type-0xc variant used by other voice formats, not by the shipped Kendra/Amy files.",
    "container": "gap = continuous stream of `u16le len; u8 payload[len]` packets; every record's gap_off lands exactly on a packet boundary (15015/15015 verified) and every window walk consumes exactly gap_len bytes.",
    "record_fields": "u16 N; u16 ramp[N]; u16 Y; u32 gap_off (byte 2N+4); u32 gap_len (byte 2N+8); rec_len=2N+12; total unit samples = ramp[N-1]; Y = codec-delay samples to discard.",
    "deobfuscation": "m=n&~3; key=le32(checksum)||(payload[m:n] padded to 4); payload[i]^=key[i%8] for i<m. Verified byte-exact vs engine (hook on FUN_00147c58). Corroborated by decompiled FUN_00067a14 and FUN_000685c4.",
    "crypto": "Enumerated all callers of FUN_000b8fe0/FUN_000b950c/FUN_000b974c/FUN_000b34fc/FUN_000b2684: only FUN_000346d4 (ISEF) and FUN_00051c70/FUN_00052154 (certificate) are application-level; the rest are OpenSSL internals (rsa_sign.c, EVP dispatch). No RSA/AES touches the gap.",
    "codec": "Proprietary fixed-point transform codec: ctx size 0x3570 (FUN_0014794c), reset FUN_0014e248, frame decode FUN_00147c58; Huffman reader FUN_0014af88 with static .rodata codebooks; integer MDCT (Q31 twiddle 0x5a82799a); native 24 kHz; 2400 samples/packet; inter-frame stateful (hence overlapping windows + Y warm-up skip)."
  },
  "deliverables": {
    "scripts/decode_unit.py": "Runnable decoder: parses CDXV header/index/record, emulates FUN_00067a14 (or drives FUN_00147c58 with a pure-python front-end), writes mono s16 WAV. Modes: --record N --out F.wav, --list, --dump-packets, --python-decode, --verify, --rate (default 24000).",
    "report_gap_codec.md": "Full write-up: byte-level evidence, Ghidra/ELF addresses, container+transform spec, crypto-caller table, codec characterisation, verified results, undetermined list.",
    "artifacts": "out/gap/kendra_unit{0,1,3,5}.wav, out/gap/amy_unit1.wav, out/gap/kendra_unit3_spectrogram.png."
  },
  "verification": {
    "length_matches_record": "decoded sample count == ramp[N-1] for all tested records (Kendra 15/15 incl. 0-14,100,1000,10000,100000; Amy 8/8 incl. 0,1,2,3,5,10,100,100000).",
    "front_end_and_driver_bit_exact": "--verify: engine path (FUN_00067a14) == python front-end + direct FUN_00147c58 driver, identical for records 0,1,2,5,13,100,1000 (e.g. rec0 4537/4537).",
    "speech_confirmed": "rec3 output: dominant F0 ~138 Hz, autocorr 0.76, spectrogram shows harmonic stack + formants."
  },
  "undetermined": [
    "exact codec library identity (structure resembles RealAudio Cook/G2 but not positively identified); a clean-room port would need the whole 0x147xxx family",
    "exact ramp[] semantics / per-unit segmentation in LAB_00067db8 (needed for synthesis placement, not for PCM)",
    "downstream 24000->22050 resample (resample_wave FUN_00059958) not traced end-to-end",
    "single-pass continuous decode aligns at stream_sample(gap_off)+Y but differs ~17% (codec not fully convergent within the warm-up); per-window decode is the faithful semantics"
  ],
  "notes": "Only new files created under scripts/, out/ and the one report; originals untouched (read-only). Scratch probes removed after use."
}