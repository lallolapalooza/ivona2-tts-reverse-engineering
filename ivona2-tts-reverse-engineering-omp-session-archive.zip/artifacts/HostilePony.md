{
  "status": "complete",
  "summary": "The IVONA acoustic codec is fully ported to stdlib Python; codec_spec.py reproduces the original engine's PCM bit-exactly, with no Unicorn at runtime.",
  "deliverables": {
    "decoder": "scripts/codec_spec.py (stdlib only: argparse/array/os/struct/sys/wave + codec_parts; --record N --obb PATH --rate HZ --out f.wav --dump-stage STAGE --list)",
    "core_stage": "scripts/codec_parts/parse.py (range decoder + parse), dequant.py, setup.py, gain.py, xform.py, post.py",
    "shared": "scripts/codec_parts/dsp.py (f1496c0/f14dc30/f14dca4/f150a14/f14f940/f151448), resample.py (FUN_0014b668/6b6d0/4a8/4c494 + 2x stage), prims.py, tables.py, harness.py",
    "verification": "scripts/verify_codec.py (chained stages), scripts/compare_spec.py (vs emulator oracle), scripts/codec_parts/test_resample.py, scripts/codec_parts/test_setup.py; diagnostics scripts/trace_calls.py, scripts/trace_af88.py",
    "report": "report_codec_spec.md rewritten (stage spec, context layout, table map, fixed-point conventions, driver incl. rate conversion, verification table, emulation dependencies)"
  },
  "verification": {
    "per_stage": "setup 55/55, gain 55/55, post 55/55, parse 55/55, dequant 55/55, xform 55/55 byte-identical (all 336 recorded stage calls, 4 buffers each)",
    "chained": "scripts/verify_codec.py: files=6 steps=336 buffer-compares=1344 failed=0 (fresh reset -> bitinit->parse->dequant->setup->gain->xform->post, every intermediate buffer compared to the engine snapshot)",
    "resampler": "scripts/codec_parts/test_resample.py: kendra 5/5 + amy 5/5 records BIT-IDENTICAL for 24000->22050",
    "end_to_end_22050": "scripts/compare_spec.py --voice kendra --count 60 => picked=59 tested=59 bit-identical=59 failed=0 (266.0s); --voice amy --count 60 => 59/59 failed=0 (239.9s); records spread 0..419753 (kendra) / 0..397984 (amy)",
    "end_to_end_24000": "same comparison with --rate 24000 (resampler disabled): kendra 59/59, amy 59/59, failed=0",
    "cli_to_cli": "cmp of decode_unit.py --rate 22050 vs codec_spec.py WAVs: IDENTICAL for kendra rec 0 and 419753, amy rec 0 and 397984",
    "dump_stage": "codec_spec.py --record 0 --dump-stage xform matches rec000000.pkl exactly (ctx 13680/13680, samp 8192/8192, frame_info 512/512)"
  },
  "key_findings": [
    "decode_unit.py --rate 22050 (the stated acceptance oracle) does NOT just set the WAV header: FUN_00147c58 engages an internal resampler when the requested rate differs from the codec's 24000 Hz, so its PCM is materially different from --rate 24000 (unit 0 rms 2145 vs 916). The resampler therefore had to be ported too, and codec_spec's --rate now defaults to the OBB's declared rate (22050) and implements the same conversion; --rate 24000 returns the codec-domain samples.",
    "Three Ghidra peculiarities were load-bearing for bit-exactness: in FUN_00148a20 the 6-bit band-symbol array (local_a4) drives FUN_0014d100 while the escape-count array (local_11c) drives the extra-bit loop; FUN_0014d100's early bail-out paths write coefficients 0/1 as zero (shared store) rather than leaving them; calls with fewer args (e.g. FUN_0014b4a8's flush call) reuse leftover registers and are really full 4-argument calls."
  ],
  "residual": "No divergence anywhere in the shipped-voice path. resample.py deliberately raises NotImplementedError (naming branch + engine symbol) for the polyphase converters unreachable from 24000->22050 (FUN_0014bf38, LAB_0014bdf8, DAT_0014ca68, LAB_0014be08, LAB_0014cba8, LAB_0014ca6c, the 0x13cba8 2x filter); it was separately verified against the engine for every rate pair of {8000..96000}^2 that reaches ported code (setup struct byte-identical for all 140, sample-exact for 49)."
}