{
  "report": "/home/asdf/Downloads/ivona_re/report_libtiver.md",
  "summary": "Evidence-based reverse-engineering report of libtiver.so (MD5 b381ee3b994d615c997f1b0ddd1b09bd), covering v/h/checkFiles signatures and exact behavior, the 5-word voice-info struct at ELF 0x1f004 ({20, 2, \"20130201_150739\", 48, accessor-fn}) with engine gates, the full 42-row package→obb table at ELF 0x1d538 (every field decoded; lib-size and obb-size columns verified byte-exact against on-disk amy/kendra artifacts), patch.199.<pkg>.obb extraction logic (flat entries, 8KiB copy loop, CRC ignored, skip-predicate bug documented), path grammar (<base><pkg>/main.<N>.<pkg>.obb with N∈{183,199,422}, patch always .199, probe order <sdcard>/ivona/ then <sdcard>/Android/obb/), return-code contract (0/1/-1/-2), and a byte-for-byte reimplementation checklist with [INFERENCE] markers.",
  "key_findings": [
    "h() returns int (Ghidra showed void): tail-calls internal FUN_000169b8(pkg, base, flag=0); checkFiles uses flag=1",
    "Size gate compares stat offsets 0x30/0x34 (low/high halves of 64-bit st_size) against table field [9] — exact byte size required",
    "Patch version 199 is a hardcoded C literal; main-obb N varies per voice (183/199/422) via the table",
    "Patch skip-check compares st_size against the zip entry-name length (size_filename @unz_file_info+0x1c) so entries are effectively re-extracted every call",
    "v()'s struct[4] is a Thumb function entry_by_index(i)=table+i*48 for i<=43 (mode struct[1]==2); .data words [5]/[6] are cxxabi handler pointers, not voice data",
    "Unknown package names fall through to the all-zero terminator row and dereference a NULL obb-name pointer (UB)",
    "Engine libttsivona dlopens /data/data/<pkg>/lib/libtiver.so, dlsyms \"v\"/\"h\", probes <sdcard>/ivona/ then <sdcard>/Android/obb/, and reports \"apiVer;fstate;displayName;stamp;location\" to Java"
  ],
  "artifacts": [
    "report_libtiver.md (the deliverable)",
    "scripts/table_full.json — full decoded 42-row table incl. localized trial messages",
    "scripts/parse_table.py, parse_data_struct.py, dump_full_table.py, disasm_169b8.py, disasm_range.py — reproducible extraction/disasm scratch scripts"
  ],
  "sibling_coordination": "Findings on the engine-side consumption were cross-verified with DemocraticPossum (his report_engine_app.md §5.3/§5.6 updated); DizzyArmadillo's table/stat-size conclusions were independently reproduced and folded in with citation."
}