{
  "status": "oracle unblocked: voice loads, levels 2 and 3 captured (real PCM from the unmodified engine)",
  "harness_fixes": [
    {
      "symptom": "tts_load_voice -> voice=0, errno 4 'Failed to load voice'",
      "cause": "emu/armemu.py registered atol=strtol; strtol used r2 (garbage for the 1-arg atol call) as the conversion base -> int('1333557784', 0x182e8d8) raised -> returned 0, so the plug-in's atol('1333557784') == hdr checksum comparison in FUN_00028310 failed and the voice file was discarded",
      "fix": "armemu.py: _int_prefix() implements C strtol/atoi/atol (blanks, sign, longest valid digit run, base 0/8/10/16); strtol validates its base; atol/atoi are base-10",
      "evidence": "after the fix: tts_load_voice -> voice=0x4197e660, tts_voice_sample_rate=22050 Hz"
    },
    {
      "symptom": "tts_streamer_synth0 returned 0 frames; outer emulation stopped abnormally at pc=0x50878 (inside FUN_0005fc04) with lr=0x70000000=RET_TRAP",
      "cause": "FUN_0005fc04 ends its node-cost pass with qsort(...,0x14,LAB_0005fa64); emu/tts_run.make_qsort evaluated the comparator via nested uc.emu_start, which is not re-entrant in Unicorn 2.1.4 -- proved with a synthetic program (outer run resumes with corrupted PC / is killed by the inner emu_stop)",
      "fix": "make_qsort re-implements the comparators in Python; the ones used are unsigned u32 at +0 (engine LAB_0005fa44, plug-in LAB_0002ee1c) and u32 at +8 (LAB_0005fa64), stride 0x14, stable (== glibc merge sort); unknown comparators raise EmuError",
      "evidence": "after the fix PCM is produced and the run reaches level 3"
    },
    {
      "symptom": "every token absent from the plug-in's packed lexicon (LTS fallback) silently lost its phones; 'Hello world' produced only 'hello'; punctuation left behind was spoken by name (comma/dot)",
      "cause": "the plug-in's LTS builds its rule context with sprintf(\"%.*s...\"); armemu's printf/sprintf/snprintf formatter ignored `.*` and never consumed the `*` argument, shifting every following argument",
      "fix": "armemu.py: new ArmLib._c_format parses flags/width/precision (including `*`), length modifiers and %s/%d/%i/%u/%x/%X/%o/%c/%p/%%/%f/%e/%g; used by both the register/stack and va_list paths (printf/sprintf/snprintf/fprintf/vsprintf/vsnprintf/vfprintf). strtod also added",
      "evidence": "before: 'Hello world' -> pau-hh hh-ax ax-l l-ow ow-pau. After: pau-hh hh-ax ax-l l-ow ow-w w-er er-l l-d d-pau; 'Hello world this is a test' -> full correct chain"
    },
    {
      "symptom": "errno 9 'File not found: .../lang_en_us_kendra.dat' reported at synthesis time",
      "cause": "tts_load_voice probes lang_<code>_<voice>.dat then falls back to lang_<code>.dat; the shipped patch OBB contains only lang_en_us.dat, so the failed probe leaves errno set although the fallback succeeds (stale errno)",
      "fix": "byte-identical copies named lang_en_us_kendra.dat / lang_en_gb_amy.dat placed in out/obb (documented as cosmetic; fallback is the production path)"
    }
  ],
  "captures": {
    "recommended": {
      "dir": "out/oracle/ref_nopunct",
      "sentence": "Hello world this is a test",
      "chain": "pau-hh hh-ax ax-l l-ow ow-w w-er er-l l-d d-dh dh-ih ih-s s-ih ih-z z-ax ax-t t-eh eh-s s-t t-pau",
      "phones": "hh ax l ow | w er l d | dh ih s | ih z | ax | t eh s t",
      "pcm": "38783 frames = 1.759 s @ 22050 Hz mono int16"
    },
    "others": [
      {
        "dir": "out/oracle/ref_default",
        "sentence": "Hello world, this is a test.",
        "phones": "hh ax l ow | w er l d | k aa m ax | dh ih s | ih z | ax | t eh s t | d aa t",
        "pcm": "53649 frames = 2.433 s"
      },
      {
        "dir": "out/oracle/ref_lexclean",
        "sentence": "Hello, this is a comma dot.",
        "phones": "hh ax l ow | k aa m ax | dh ih s | ih z | ax | k aa m ax | d aa t | d aa t",
        "pcm": "49292 frames = 2.235 s"
      },
      {
        "dir": "out/oracle (top level, superseded)",
        "sentence": "Hello world, this is a test.",
        "note": "captured with the pre-fix harness; world/test missing; kept for the record"
      },
      {
        "dir": "out/oracle/exp_nopunct, exp_hello, exp_punct2",
        "note": "bisection evidence for the LTS drop"
      }
    ],
    "files_per_capture": [
      "trace.log (contains the input text as the engine received it)",
      "cmdline.txt",
      "settings.txt (viterbi_beam=25, tb_min_distance=6, duration_stretch=pitch_stretch=amplify=compress=1.0, eng_sentence_break=0.4s, eng_paragraph_break=0.65s, eng_max_sentence=1000, eng_max_word=100, pause_base_len=0, sample_rate=22050, eng_version=1.6.23, language_code=en-US)",
      "diphone_lookups.tsv (FUN_0005ef00 chain)",
      "diphonedb_names.txt (section A: 1601 names + base durations)",
      "unit_feature_vectors.tsv (96-byte FEM per FUN_00060ed4, slot map from report_cost_terms_main.md 4c in the header)",
      "candidate_lattice.txt (per position: candidate count, b_start, selected unit, variant)",
      "candidate_records.tsv (FUN_0005f1dc: 36-byte section-C record -> 96-byte vector; 2 per Viterbi pair)",
      "viterbi_candidates.tsv (engine's own per-candidate target/total/diphone costs after FUN_0005fc04)",
      "viterbi_calls.txt",
      "pipeline_calls.txt",
      "unit_sequence.txt (FUN_0005ef70 order, named via section A/B inverse, with durations and cumulative ms)",
      "prosody_transforms.tsv",
      "kendra_hello.pcm / kendra_hello.wav"
    ],
    "reproduce": "cd /home/user/Downloads/ivona_re && ~/venvs/re/bin/python emu/tts_run.py --level 3 --ret-probe --sentence \"Hello world this is a test\" --out-dir out/oracle/ref_nopunct  (~5-11 min: tts_init ~50 s RSA verify, rest is the instruction-level Python hook)"
  },
  "open_items": [
    {
      "item": "punctuation is spoken by name",
      "detail": "the plug-in's printable-ASCII symbol table (.rodata: '...asterisk, comma, dash, dot, oh, two...') spells out any punctuation that reaches phonemisation: 'Hello world, this is a test.' adds the words comma and dot. Affected tokens = the punctuation characters themselves; condition = present in the input; words are unaffected. Punctuation-free input is clean (ref_nopunct). [INFERENCE] same 'symbol with no reading' fallback the LTS words used to hit. Not fixed (would need tracing the token punc-attribute path in FUN_00043bb0/FUN_00044c1c)."
    },
    {
      "item": "token_stream.tsv unusable",
      "detail": "FUN_0006706c's hooked argument is the utterance object, not a Token, so the feature decode walks the voice parameter list. Exists in every capture dir; use diphone_lookups.tsv + unit_feature_vectors.tsv instead."
    },
    {
      "item": "first unit_feature_vectors.tsv row is all-zero",
      "detail": "the return-address probe heuristic fired once before FUN_00060ed4 wrote the buffer; rows carry item pointer + raw hex, filter on those."
    },
    {
      "item": "not attempted",
      "detail": "--ssml input, tts_streamer_synth (marks mode), the libttsivona.so/JNI layer"
    }
  ],
  "files_changed": [
    "emu/armemu.py (atol/atoi/strtol + _int_prefix, strtod, ArmLib._c_format + _fmt_read/_format_va rewrite, ArmLib.call records stop_pc/stop_lr)",
    "emu/tts_run.py (make_qsort Python comparators, return-probe instrumentation, FEM/F1DC/viterbi-node capture, new artefact writers, qsort/strtod wiring)",
    "out/oracle/** (ref_nopunct, ref_default, ref_lexclean, exp_*, README.md)",
    "report_oracle.md (rewritten)",
    "out/obb/lang_en_us_kendra.dat, out/obb/lang_en_gb_amy.dat (byte-identical copies, documented as cosmetic)"
  ],
  "unblock_summary": "The oracle is unblocked end to end: real engine under emulation loads the voice, runs the front end (tokenisation, packed-lexicon + LTS G2P, diphone graph, Viterbi), selects units and emits PCM. Level 2 and level 3 artefacts are captured with reproducible command lines; the only remaining known defect is the punctuation spell-out, bounded above, and the validated reference avoids it."
}