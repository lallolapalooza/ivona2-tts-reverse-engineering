{
  "status": "SOLVED: 2 of 3 captures BIT-EXACT, third within 69 samples (one crossfade seam)",
  "acceptance_a_pull_counts": "identical to trace.log for all three: 6615x5+5708 (nopunct), 6615x8+729 (default), 6615x7+2987 (lexclean); engine finalize want=6615 confirmed by the new trace lines",
  "acceptance_b_totals": "nopunct 38783/38783, default 53649/53649, lexclean 49292/49292 (engine/pipeline), all deltas 0",
  "acceptance_c_compare_tts": "all three: duration_delta 0.0 ms, best_lag 0 ms, envelope_correlation 1.0000, frames_within_3dB 100.0%; sample diffs 0 / 69 (ref_default, 0.13 percent, at 41988..) / 0",
  "acceptance_d_verify_all": "12/12 PASS (re-run after the SOLA wiring)",
  "verify_engine": "raw-chain splice through the real .so with the same flags: 43358 / 57781 / 52981 samples, 0 diffs each -> BIT-EXACT",
  "contract_findings": [
    "pull: want = 0.3*voice_rate = 6615, same numeric domain as pos (the engine does not scale); FUN_000618a8 copies min(want,pos), memmove(dest, dest+n*2, (capacity-n)*2) so pos -= n and the pending tail rides the slide; the item-list end finalises n=pos and drops the pending tail (trace: pos0/tail0 per call, e.g. nopunct #4 pos0=90 tail0=135, #11 pos0=0 tail0=148)",
    "concat flag: flag=0 iff the next item's diphone feature (the voxdb record index = our unit id, NOT the section-A index) is cur+1; verified 19/19, 25/25, 25/26 transitions; the last unit gets flag=1 (its tail is dropped by the utterance-end finalize)",
    "no resampling: the voice defines no resample_wave, so FUN_0005d7c4's conditional FUN_00059958 never runs - the engine's wave is the codec-domain (24 kHz) stream labelled 22050 Hz (proven by the sample-identity at a fixed offset); refimpl/tts.py now matches, --resample opts back in",
    "pau restretch: FUN_0005d7c4:42256-42400 computes k=(int)(0.5*dur_ms/1000*rate), i=FUN_00062500(obj,k) + midpoint snap, then FUN_00063350(obj, 0..i or i+1..N-1, target=(int)(rate*(end(seg)-end(prev)))) -> FUN_00062d14 SOLA; refimpl/tts.py:pause_align reproduces the engine's 6/6 setlen calls",
    "SOLA (FUN_00062d14) implemented in segment_unit.stretch_pass/stretch and verified pass-by-pass against the real function via scripts/probe_stretch.py: unit 294435 win 0..16 factor 0.5/0.25/0.125/0.08775 -> N=17/13/11/10 with pms and ALL samples identical; (40107,10..29,0.5) -> N=20/2945 identical"
  ],
  "remaining": "ref_default 69 samples (0.13 percent) in one crossfade seam at 41988: the concat-flag transition 237953->237954, whose ids are adjacent and whose voxdb records are contiguous yet which the engine splices with flag 1 - i.e. an extra item in the engine's item chain that emits no audio (0 FUN_00061804 pad calls in all three captures) and also cuts the chunk there (a finalize sits exactly between). Everything else, including that seam's length, is reproduced.",
  "smallest_next_step": "probe the item chain's feature lists at FUN_0005d7c4:42382 (the flag decision, where FUN_00058e40(item) is taken; the item cursor is *(streamer+8)) for ref_default and see which feature test fails - then model the extra item or fold the condition into unit_flags (report_pipeline.md sec.13.8).",
  "files": {
    "modified": [
      "refimpl/tts.py (unit_flags by unit id, pause_align, applied restretch, stream_chunks, stream_len_model driven by flags, --resample off by default, --verify-engine compares the raw chain, [pau]/[pull] diagnostics, JSON carries concat_flags/pause_align/stream_chunks)",
      "scripts/segment_unit.py (stretch_pass/stretch = FUN_00062d14; splice need = pms[-1] as FUN_000624e8(obj,0,N-1))",
      "emu/tts_run.py (--stream-probe: streams pos/tail/total around splice/finalize/pad/trim to stream_trace.txt; object read via the pms pointer; separate _stream_watch so --ret-probe cannot clobber it)",
      "report_pipeline.md (new sec.13)",
      "REPLICATION_STATUS.md (sec.4 residual replaced with the measured outcome)"
    ],
    "added": [
      "scripts/probe_stream_contract.py",
      "scripts/probe_stretch.py",
      "out/oracle/stream_nopunct/, stream_default/, stream_lexclean/ (instrumented captures + stream_trace.txt)",
      "out/engine_match/{nopunct,default,lexclean}_codec.{wav,json}"
    ],
    "untouched": "the deleted omp-session-*.html in the working tree is not mine"
  }
}