{
  "status": "complete (partial model, with two cost layers fully validated)",
  "deliverables": {
    "scripts/prosody.py": "join cost (5 variants) + target cost (FUN_000309a4) + dispatcher (FUN_00031234) + duration CART parse/eval + pause rules",
    "scripts/probe_prosody.py": "bit-exact validator vs the real plugin under Unicorn",
    "scripts/select_units.py": "Viterbi over a diphone lattice (beam + backtrace)",
    "report_prosody.md": "full write-up: formulas, constants, addresses, worked examples, reference vectors, open items",
    "out/intonation_decomp.c": "re-decompiled engine intonation/pause/to-segments defaults (FUN_00066554/666c8/667e0)",
    "out/phrase_endtone.c": "re-decompiled plugin endtone helper (0x32d20) and FUN_00032b70"
  },
  "validated": {
    "join_costs": "5 functions (FUN_0003055c/313d0/31868/31cb0/320f0), 2500 cases each, 12500/12500 bit-identical",
    "target_cost": "FUN_000309a4 1250/1250, dispatcher FUN_00031234 1250/1250",
    "command": "~/venvs/re/bin/python scripts/probe_prosody.py --n 2500 -> TOTAL 15000/15000 bit-identical",
    "helpers_verified_by_emulation": "FUN_0006449c=fadd, 4498=fsub, 646e0=fmul, 64878=fdiv, 64634=i2f, 6462c=u2f, 64ac0=a>b, 64aac=a>=b, 64a84=a<b, 64ad4/64b30=f2iz"
  },
  "key_findings": [
    "join cost is called by the engine at libttsivonavoice.c:43473 with RAW 36-byte diphonedb records (`rec[prev+1]`, `rec[cur]`, budget=int) - NOT 96-byte feature vectors (corrects report_cost_terms_main.md); target cost gets decoded/feature 96-byte vectors",
    "join-cost skeleton: duration penalty (u16@10), ratio penalty (u16@0), class ladder (u16@8, 1e6 penalty is ADDED not an early return), field ladders (i16@12, u16@14), and a 16-byte spectral distance split 3/3/3/7 with weights 1/.75/.5/.25 and an int-truncation between groups; per-context scale = 9.6 (r) / 2 (+) / 4 (g,l) / 0.8 (- and default)",
    "duration model = zdur_cart CART: blob {phone_tbl,name_tbl,node_tbl} = {0x56ee0,0x56ff0,0x588b0} in the plugin; phone table = 44 phones with base mean/std ms; tree = 3951 nodes/1584 leaves, all equality questions over Festival feature paths; leaf = (leaf16*std +/- 500)/1000 + mean; duration_func FUN_00048400 writes cumulative `end` seconds",
    "pause rule: prev==NULL -> 0.01; 'BB' phrase (read from prev) -> 0.35+0.05 = 0.40, +0.10 if a next segment exists -> 0.50; else 0.20",
    "intonation stage (ENGINE FUN_00066554) only assigns a phrase-final `endtone` (Token H/L wins, else the voice's phrasesylendtone_func, else a default) - IVONA Kendra has no parametric F0 model; pitch lives in the selected units and is scaled by pitch_stretch (FUN_00063540, with duration compensation) / duration_stretch (FUN_00062d14)",
    "Viterbi FUN_0005fc04: 20-byte candidate entries, >51-bucket cost histogram beam (viterbi_beam=50, 25 at low quality), 0-dB join cost for consecutive diphone indices, backpointers at +0x10"
  ],
  "not_pinned_down": [
    "duration CART not run end-to-end (FUN_00048110 needs a Festival item + the plugin feature registry; harness prerequisite identified)",
    "plugin phrasesylendtone_func at 0x32d20 ambiguous (decompiles like a registration routine; likely a Ghidra boundary issue)",
    "Viterbi structure transcribed not diffed (full-engine oracle blocked: tts_load_voice fails)",
    "full-engine reference PCM unavailable"
  ],
  "files_added": [
    "/home/user/Downloads/ivona_re/scripts/prosody.py",
    "/home/user/Downloads/ivona_re/scripts/probe_prosody.py",
    "/home/user/Downloads/ivona_re/scripts/select_units.py",
    "/home/user/Downloads/ivona_re/report_prosody.md",
    "/home/user/Downloads/ivona_re/out/intonation_decomp.c",
    "/home/user/Downloads/ivona_re/out/phrase_endtone.c"
  ],
  "notes": "Originals untouched. The five join costs plus the target cost and dispatcher are reproduced bit-exactly; a port can now reproduce the engine's chosen unit sequence given candidate lattices and feature vectors. `report_cost_terms_main.md` (Main's share) is superseded/completed for the target cost by report_prosody.md §2 (two byte tests 0x44 and 0x48 were missing there; ph_vc char comes from param_2)."
}