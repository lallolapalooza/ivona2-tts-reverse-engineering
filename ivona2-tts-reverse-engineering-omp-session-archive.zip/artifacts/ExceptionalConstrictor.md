{
  "status": "complete",
  "deliverables": {
    "pipeline": "refimpl/tts.py (CLI: --text --voice kendra|amy --out --rate [--codec-rate --select --align --json --verify-engine --phones --check-tables --check-g2p])",
    "analysis": "scripts/analyze_tts.py (durations, RMS envelope, autocorr F0, phone-level alignment, ffmpeg spectrogram PNG)",
    "demos": "out/tts_demo/{hello_world,kendra_speaks,quick_brown_fox,amy_hello_world,hello_first,hello_first_22k}.wav + .json + .log + *_analysis.txt + *_spec.png",
    "report": "report_pipeline.md",
    "read_only": "originals untouched; only the four paths above were written"
  },
  "verification": {
    "a_phone_sequence": "35/35 words identical to scripts/lex_decode.py || scripts/lts_decode.py (after documented stress-digit strip for the diphone key); 30/30 diphone pairs of the acceptance sentence present in section A; 151/151 for a 35-word chain; 215 transitions / 0 absent across 9 sentences",
    "b_duration": "committed samples == independent stream_len_model for every run (hello world 27102, Kendra speaks 37438, pangram 68843, Amy 29254, hello/first 21190); duration = pos/24000 = WAV samples/22050",
    "engine_equivalence": "same unit chain re-spliced through real libttsivonavoice.so: 27102/27102 and 68843/68843 samples, 0 diffs (BIT-EXACT) for the two sentences run with --verify-engine",
    "c_objective_audio": "per-demo peak/RMS dBFS, 10 ms envelope + silence runs, autocorr F0 (median 148/145/162/162 Hz), phone-level alignment table with per-unit start/end/out_ms vs recorded dur_ms, spectrogram PNGs; NO subjective listening claim (no audio output available here) - intelligibility argument stated as INFERENCE",
    "structural": "A->B->index->C chain: section C bytes 4,5 == diphone phone ids for 418495/418495 (Kendra) and 396683/396683 (Amy)"
  },
  "deviation_highlights": [
    "no Viterbi: documented stand-in (identity gate on bytes 4,5, then context match on bytes 2,3,6, then lowest unit id); 'first candidate' available via --select first",
    "no prosody (pitch/duration/gain/compress), no 96-byte features, no intonation - flat prosody, occasional spectral seams (adjacency 4/8, 4/17, 5/29, 2/8)",
    "no SSML/ISEF rewrite rules; digits spelled out; punctuation -> clause pauses",
    "amy uses the en-US front end (measured to be what her plug-in embeds); en-GB-only symbols never produced",
    "335/1936 diphone pairs absent from section A (e.g. eh-pau, pau-ng) - skipped and reported",
    "resample_wave FUN_00059958 untraced -> Hamming-windowed sinc stand-in (validated: 1000.1 Hz tone preserved, duration exact)",
    "the emulated codec (scripts/decode_unit.py) is the only non-clean-room stage; drop-in point is the single Codec.decode_window call in tts.py:synth"
  ],
  "suggested_main_agent_checks": [
    "~/venvs/re/bin/python refimpl/tts.py --text \"hello world\" --out /tmp/x.wav --verify-engine  (expect BIT-EXACT, 0 diffs)",
    "~/venvs/re/bin/python refimpl/tts.py --check-tables  and  --check-tables --voice amy  (expect 0 bad)",
    "~/venvs/re/bin/python refimpl/tts.py --check-g2p \"hello kendra world\"  (expect all OK)",
    "~/venvs/re/bin/python scripts/analyze_tts.py out/tts_demo/quick_brown_fox.wav --json out/tts_demo/quick_brown_fox.json",
    "audition out/tts_demo/quick_brown_fox.wav (the only step this environment could not do)"
  ]
}