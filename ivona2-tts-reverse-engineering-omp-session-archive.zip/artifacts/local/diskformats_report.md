# On-disk formats of libttsivonavoice.so (IVONA 2 TTS core)

Dump = `/home/user/Downloads/ivona_re/out/ghidra_dump/libttsivonavoice.c` (addr = ELF vaddr + 0x10000).
Binary = `out/libs/kendra/libttsivonavoice.so` (rodata vaddr == file offset; file offset = dump addr - 0x10000).
OBB = `main.199...obb` (152,219,597 B).

## 0. File-open plumbing (shared)

- `FUN_0005b368 @ 0x5b368` (dump:39759-39796): fopen wrapper; mode bits -> string; arg 10 = "rb"
  (bit1='r', bit3 appends 2 bytes from file offset 0x147270 = "b").
- `FUN_0005b338 @ 0x5b338` (dump:39753-39757): fread wrapper (fread(ptr,size,nmemb,fp)).
- `FUN_000505ac @ 0x505ac` (dump:30491-30506): generic file reader: `fopen(name,"rb")`, on failure
  `FUN_00047628(errno,"file_open")`; returns 0x18-B handle {.., FILE* at +0x14}. Used by ISEF,
  dict and PLS loaders.
- `FUN_00067830 @ 0x67830` (dump:47240-47263): mmap wrapper: open(O_RDONLY),
  mmap(PROT_READ, MAP_PRIVATE), page-rounded length; handle {void* map, size, fd}.

## 1. CDXV container (vox voice-data file; the OBB main file is this format)

### 1.1 Magic validation - 3 readers, all `fread(hdr,0x68,1,fp)` then LE u32 `0x56584443` ("CDXV"):

- `FUN_0005f064 @ 0x5f064` (dump:42513-42560): magic check dump:42531; then dump:42534 compares
  hdr u32 @ +0x24 vs caller[3] and hdr u32 @ +0x2c vs caller[4] (sample-rate + checksum validation);
  optional validate callback at caller[0xd] (dump:42537-42541). This is the **streamer reopen** path:
  called from `FUN_0005d7c4 @ 0x5d7c4` dump:41849 with the already-loaded diphonedb struct
  (re-opens same file, checks header again, then runs the version decoder).
- `FUN_0005f424 @ 0x5f424` (dump:42707-42736): header-only check (magic dump:42724), returns
  strdup of name field.
- `FUN_0005f49c @ 0x5f49c` (dump:42738-42882): main parser (magic dump:42777).
- Inline "CDXV" ASCII in .text literal pools at file offsets 0x4f164/0x4f498/0x4f774 (anchor given;
  consistent with the three functions above at ELF 0x4f064/0x4f424/0x4f49c). A duplicate engine-side
  copy also exists in `libvoice_en_us_kendra.so` at file 0x17cd0 (plugin exports
  `register_voice@@TTS_ENGINE_1_6`, has no engine imports - self-contained duplicate).

### 1.2 Header layout (104 = 0x68 bytes; little-endian; derived from FUN_0005f49c stack map
local_80->+0x00 ... local_1c->+0x64, dump:42746-42882; confirmed against OBB bytes):

| off | size | field | evidence |
|---|---|---|---|
| 0x00 | 4 | magic "CDXV" (LE 0x56584443) | dump:42777; OBB bytes 43 44 58 56 |
| 0x04 | 32 | voice name, NUL-padded ("vox_en_us_kendra\0..") | strdup via FUN_0005b884 (dump:42779-42781; FUN_0005b884 = strdup, dump:40030-40043); OBB bytes; strcmp vs config `name` in FUN_0005f7a4 dump:42940 |
| 0x24 | 4 | sample rate (OBB = 22050 = 0x5622) | struct[3] dump:42782; feature "sample_rate" dump:42957; FUN_00067f94 remaps 0x5622->24000 dump:47532 |
| 0x28 | 4 | format/codec version id (OBB = 14) | switch dump:42846-42879 selects per-version callbacks [0xd]/[0xe]/[0xf]; v14 -> FUN_00067f94/LAB_000679e0/LAB_00067db8 |
| 0x2c | 4 | checksum / file tag (OBB = 0x4f7c7a18) | struct[4] dump:42783; atol("checksum") compare dump:42943-42944; re-checked on reopen dump:42534; 4 bytes spread into streamer ctx dump:47539-47542 |
| 0x30 | 4 | section A file offset (OBB = 0x68 = header size) | `puVar2[5] = map + local_50` dump:42826 -> points at file offset 0x68 = **section directory** |
| 0x34 | 4 | section A size (OBB = 3,415,928) | `puVar2[6] = local_4c` dump:42830 |
| 0x38 | 4 | section B offset (OBB = 25,356,504 = end-of-data) | `puVar2[0x10] = map + local_48` dump:42827-42829, guarded by +0x3c != 0 |
| 0x3c | 4 | section B size (OBB = 0 -> ptr not set) | guard dump:42827; also `puVar2[0x11] = local_44` dump:42784 |
| 0x40 | 4 | section C offset (OBB = 3,416,032) | `puVar2[10] = map + local_40` dump:42810-42813 |
| 0x44 | 4 | section C size (OBB = 32,020 = 1601x0x14) | count `puVar2[0xb] = local_3c/0x14` dump:42812 (20-byte records); qsort 0x14-records FUN_0005fa84 dump:42974-42982 |
| 0x48 | 4 | section D offset (OBB = 3,448,056) | `puVar2[9] = map + local_38` dump:42814-42816 |
| 0x4c | 4 | section D size (OBB = 1,673,980) | mmap-length computation dump:42787-42804 |
| 0x50 | 4 | section E offset (OBB = 5,122,040) | `puVar2[8] = map + local_30` dump:42817-42819 |
| 0x54 | 4 | section E size (OBB = 15,371,676) | mmap-length computation dump:42787-42804 |
| 0x58 | 4 | section F offset (OBB = 20,493,720) | `puVar2[7] = map + local_28` dump:42820-42822 |
| 0x5c | 4 | section F size (OBB = 4,860,925) | mmap-length computation dump:42787-42804 |
| 0x60 | 4 | section G offset (OBB = 25,354,648) | `puVar2[0xc] = map + local_20` dump:42823-42825 |
| 0x64 | 4 | section G size (OBB = 1,856; off+size = 25,356,504 = max end = mmap length) | mmap len uVar5 = max over pairs dump:42787-42804; OBB: last pair ends exactly at 25,356,504 = hdr +0x38 value |

Endianness: all LE (direct `*(int*)` reads, no swap in FUN_0005f49c).

### 1.3 How the engine uses it

- `FUN_0005f49c` mmaps only the header-described range (0x68 + 25,356,504 = 25,356,608 B) via
  FUN_00067830 (dump:42805). Section offsets/sizes are near-contiguous (3-4 B gaps = alignment
  padding [INFERENCE]).
- **Lazy section directory at file offset 0x68**: `FUN_0005ef70 @ 0x5ef70` (dump:42455-42481)
  treats `*(blob+0x14)` (= map+0x68, hdr field 0x30) as an array of 8-byte
  `{u32 file_offset, u32 size}` indexed by section number; mallocs, `fseek(fp,off,0)`,
  `fread(buf,1,size,fp)` on the stdio handle from FUN_0005f064, error
  `"**Error: voxdb read: \`%s'\n"` (dump:42470); then calls parse callback `*(blob+0x3c)`
  (= the v14 parser) on the bytes. Verified against OBB: entries at 0x68 are e.g.
  {off 133,873,411, size 76}, {133,873,487, 58}, {133,873,545, 68} .. - they point deep into the
  152 MB file, **beyond** the 25.4 MB mmap (hence the stdio path). Directory count:
  [INFERENCE: comes from the 1601-entry 0x14-record table at hdr 0x40; not fully traced -
  voxdb-agent scope].
- `FUN_0005f7a4 @ 0x5f7a4` (dump:42884-42972): config-driven loader. Reads config keys `name`
  (DAT_00155d00 = "name", file off 0x145d00) and `"checksum"`; if a directory is given, builds
  voxdb path `sprintf("%s/%s/%s/%s%s", dir, voxdbname, checksum, voxdbname, "22v")`
  (format at file off 0x148b38; suffix literal "22v" at 0x148b48; identical literals in the voice
  plugin) - i.e. `<dir>/<voxdbname>/<checksum>/<voxdbname>22v` [INFERENCE: suffix semantics].
  Requires 5 features non-NULL (table@0x40 and regions 0x48/0x50/0x58/0x60) else
  `"**Error: file \`%s' lacks needed features\n"` dump:42963; publishes feature `diphonedb`
  (val type 0x1f, FUN_0005f3b4/f3cc dump:42669-42705, error
  `"VAL: tried to access %s in %d type val\n","diphonedb"` dump:42700). Errors:
  `"**Error: cannot open or incorrect file \`%s'\n"` dump:42934.
- `FUN_00067f94 @ 0x67f94` (dump:47514-47557): v14 open callback - sample-rate sentinel
  0x5622->24000 (dump:47532), checksum bytes stored into decoder ctx (dump:47539-47542),
  then inits a codec (FUN_0014794c..).
- Sections actually dereferenced at load: 0x40-table (1601x20 B records; also qsorted 0x14-records,
  FUN_0005fa84), regions 0x48/0x50/0x58/0x60 (mandatory), 0x30 -> directory at 0x68 (lazy),
  optional 0x38-pair. Beyond that is per-feature deep parsing (voxdb/streamer agent scope).

## 2. lang_*.dat ("ISEF" magic) - encrypted lexicon container

### 2.1 Filename construction (tts_load_voice @ 0x4c028, dump:28046-28243)

- `getenv("IVONA_LANG_DAT_DIR")` dump:28081 (else dir = dirname of the voice .so path,
  dump:28083-28100).
- `FUN_0004be40 @ 0x4be40` dump:27878-27897: appends `"lang_"` + language_code ('-'/' ' -> '_')
  + `"_"` (DAT_00156f74, file 0x146f74) + ASCII-normalized voice-name variant (' '/'/' -> '_'
  via FUN_0005519c, dump:34599-34615) + `".dat"` (DAT_00156f78, file 0x146f78) ->
  e.g. `lang_en_us_kendra.dat`.
- Fallback `FUN_0004bfb8 @ 0x4bfb8` dump:27951-27966: `"lang_" + language_code + ".dat"` ->
  `lang_en_us.dat` (matches patch OBB files). First choice tried dump:28102-28104; fallback
  dump:28106-28110; both fail -> voice load aborts (dump:28111-28120).
- Open/parse: `FUN_00039300 @ 0x39300` dump:15702-15768.

### 2.2 Cache + parse path

- `FUN_00039300` dump:15708: `stat()` (error `"File not found: %s"` dump:15775); per-path cache
  keyed on strdup(path) + stat timestamp field (`sStack_90.__unused4`, compare dump:15741,
  likely st_mtime [INFERENCE]); refcounted; re-parse when timestamp differs.
- `FUN_000394b8 @ 0x394b8` dump:15771-15830: opens container via `FUN_000346d4`; reads section
  `"prm_lex_list"` (default content `"prm_lexicon\n"` len 0xC, dump:12622-12625); iterates its
  newline-separated names; for each name N parses bytes into the lexicon as UTF-8 via
  `FUN_0004620c(stream,"UTF-8",lex, "<file>:<N>",0,0)` (dump:12640-12647).

### 2.3 ISEF container format (`FUN_000346d4 @ 0x346d4`, dump:12617-12741)

| off | size | field | evidence |
|---|---|---|---|
| 0x00 | 4 | magic "ISEF" | memcmp vs DAT_00155244 (file 0x145244 = "ISEF") dump:12656; lang_en_us.dat bytes 49 53 45 46 |
| 0x04 | 4 | version = BE 1 | memcmp vs DAT_0015bd70 dump:12662 (see note); files have 00 00 00 01; mismatch -> `"Invalid version of file %s"` dump:12732. NOTE: bytes at file 0x14bd70 are "Port" - decompiler pointer resolution suspect [UNRESOLVED] |
| 0x08 | 4 | BE u32 = 0x50992bcc (1352215500; identical en_us/en_gb; ~2012-11-05 -> build timestamp [INFERENCE]) | byteswapped into container[4] dump:12667-12674 |
| 0x0c | 0x200 | RSA-wrapped session blob | see below |
| 0x20c | .. | remainder: block-cipher-encrypted payload | see below |

Crypto (embedded mbedtls-style code):

- Fixed 512-byte modulus N from file off 0x14bd78 (FUN_000b2684, dump:12683) and 4-byte exponent
  from 0x14bf78 = `00 01 00 01` = 65537 (dump:12685) -> **RSA-4096 public key**; failure ->
  `"Load key"` dump:12690.
- Decrypts first 0x200 file bytes (`FUN_000b34fc(0x200,in,out,ctx,1)` vtable dispatch dump:12689);
  success check `(ret & 0x1fffffff) == 0x40` dump:12698 -> 0x40-byte session blob; failure ->
  `"Invalid file %s"`.
- `FUN_000b8fe0(puVar9, mode, 0, blob, blob+0x20)` (dump:12702 -> FUN_000ba7ec) initializes a
  **block cipher with key = blob[0..], IV = blob+0x20** [INFERENCE: AES-256-CBC, 32-B key +
  16-B IV; generic EVP wrapper `FUN_000b9030` dump:70472-70543 carries literals "evp_enc.c" /
  "bl <= (int)sizeof(ctx->buf)"]; streaming decrypt of rest of file (FUN_000b950c dump:12715),
  finish+unpad FUN_000b974c dump:12716-12723; failure -> `"Broken file %s"` dump:12704.
- lang_en_us.dat: 74,668 B = 12 + 0x200 + 74,144 (74,144 % 16 == 0 -> CBC padding consistent).
- Payload = **decrypted section table**: `FUN_000345b0 @ 0x345b0` dump:12561-12592 walks records
  `{char name[16] (NUL-padded, pad bytes from .bss DAT_001a4178 = 0), u32be size, u8 data[size]}`;
  name match = memcmp name + zero-pad; next record at cur+size+0x14. Each section's data is
  **lexicon text** (format section 3) parsed by FUN_0004620c.
- **Cannot decrypt contents** without IVONA's RSA private key - section names inside a shipped
  lang_*.dat beyond "prm_lex_list" are [UNDETERMINED].

## 3. Lexicon/dictionary text format (shared by dict files and ISEF sections)

Parser `FUN_0004620c @ 0x4620c` (dump:23783-24093):

- Encoding sniff: `FF FE`->UTF-16LE, `FE FF`->UTF-16BE, `EF BB BF`->UTF-8, `#&`-directive first
  line with `key=value` pairs (only `encoding=` honored; unsupported ->
  `"Lexicon encoding not supported: %s"` dump:23895), else default encoding from arg ("UTF-8")
  (dump:23824-23903).
- Line tokenizer `FUN_00045eac @ 0x45eac` dump:23632-23656 + `FUN_00045dc0 @ 0x45dc0`
  dump:23572-23618: empty lines and lines starting `#` skipped; two whitespace-separated tokens
  per line: `pattern replacement`; tokens may be double-quoted; backslash escapes (incl. `\"`)
  supported; unterminated quote -> `"invalid dictionary format"` (dump:24033). Max 100 errors
  (`"Too many errors. Quitting"` dump:24041); errors as `"line %ld: %s"` (dump:24021).
- Each accepted line becomes a **regex rule** via `FUN_00046e10 @ 0x46e10` dump:23953-24056:
  PCRE compile (FUN_00080db8 flags 0x20002801) with POSIX-class rewrites
  [:graph:]/[:lower:]/..; entry (20 B):
  {char* pattern|0, char* replacement, pcre* code, pcre_extra* analysis, char* tag}
  (dump:24013-24027). Semantics = grapheme-rewrite rules, not word->pronunciation pairs
  [established from code].

## 4. tts_dict_save / tts_dict_load / tts_dict_insert

- `tts_dict_save @ 0x45f64` (dump:23677-23753): text file; `fopen(path,"w")` (error
  `"Cannot open file for writing"` dump:23700); writes literal `#& encoding=UTF-8\n` (18 B,
  dump:23704); per entry: pattern then replacement separated by one space, line ends `\n`;
  `"` escaped as `\"`; a token is wrapped in `"..."` iff empty or contains space/\t/\n/\r
  (dump:23724-23748); optional 3rd arg filters by entry tag (entry+0x10, dump:23712-23715).
- `tts_dict_load @ 0x46a6c` (dump:24119-24204): local path -> `FUN_00046a10` dump:24095-24107
  (FUN_000505ac + FUN_0004620c + close); `file://`/`http://` -> fetch via
  `FUN_0004bc88 @ 0x4bc88` dump:27793-27823 (config `eng_ssml_base_uri`/`eng_fetch_function`/
  `eng_fetch_user_data`) then parse from memory buffer (dump:24148-24160; error
  `"Failed fetching lexicon file"` dump:24167). Config keys `eng_dict_insert_id` (tag) and
  `eng_text_encoding` (default "UTF-8") (dump:24141-24143). Returns entry count or -1.
- `tts_dict_insert @ 0x47158` dump:24394-24460: converts both args via FUN_00055318(encoding)
  then same rule insert (no file).

## 5. tts_pls_load - W3C PLS 1.0 XML via embedded expat 2.0.1

- `tts_pls_load @ 0x3c6a8` (dump:28215-28380). Non-URL path: whole-file read via FUN_000505ac
  (dump:28238-28244); `file://`/`http://` -> fetcher path (dump:28275-28360; errors
  `"Failed parsing PLS lexicon file"` dump:28257/28328; `"Too many PLS lexicons"` at id
  0x7ffffffe dump:28287).
- Parser `FUN_0003816c @ 0x3816c` (dump:14853-14957): `XML_ParserCreateNS`-equivalent
  FUN_000fa864(0,'^') (namespace sep 0x5e) - .rodata strings "expat_2.0.1", "lib/xmlparse.c";
  token regex `[\p{L}\p{M}\p{N}]+|[\p{S}]|[\p{P}]|[\p{Z}\p{C}]+` (dump:14874); result =
  FUN_00036f10 lexicon object.
- Element handler `FUN_000388dc @ 0x388dc` (dump:15207-15410): element table at .data.rel.ro
  DAT_0018fd20 starts "lexicon"; requires root `lexicon` (W3C PLS namespace
  `http://www.w3.org/2005/01/pronunciation-lexicon`, assumed when unbound, dump:15237-15252);
  checks `version` attr ("1.0") and `alphabet` (dump:15350-15410); warning "PLS element names
  should be lowercase"; sub-elements phoneme/alias/sub handled (strings dump:14406-14649).
- In-memory: lexicon object; tts_pls_load stores (auto-increment id, lexicon*) pairs in engine
  vector (dump:28281-28290); `tts_pls_unload @ 0x4bd94` dump:27825-27850 removes by id.

## 6. Other formats opened by these paths

Only: CDXV vox (section 1, incl. voxdb path `<dir>/<name>/<checksum>/<name>22v`), ISEF
lang_*.dat (section 2), dict text (section 4), PLS XML (section 5); http/file URLs go through
the configured fetch callback (not a file format).

## Undetermined / [INFERENCE] list

1. ISEF second-magic pointer (file 0x14bd70 = "Port") vs observed version word 00 00 00 01 -
   decompiler pointer resolution suspect; version check semantics not byte-exact.
2. ISEF block cipher exact algorithm/key size (AES-256-CBC [INFERENCE]) and session-blob field
   split (key 32 B + IV 16 B [INFERENCE]); lang_*.dat section contents undecryptable
   (RSA-4096 wrapped).
3. BE u32 at ISEF +8 = build timestamp [INFERENCE]; consumer of container[4] not traced.
4. Section-directory (file 0x68) length/section-count source [INCOMPLETE - likely the
   1601x20 B table at hdr+0x40; voxdb-agent scope].
5. Semantics of CDXV regions 0x48/0x50/0x58/0x60 (required "features") and 20-byte record
   layout (partially: FUN_0005f1dc parses such records; qsort key 0x14 B) - voxdb/streamer scope.
6. "22v" filename suffix semantics.
7. Cached stat field in FUN_00039300 = st_mtime [INFERENCE].
8. FUN_0005519c exact ASCII normalization of voice name (case-fold [INFERENCE]).

No files were modified (all checks were inline python/readelf/grep; no scratch scripts created).
