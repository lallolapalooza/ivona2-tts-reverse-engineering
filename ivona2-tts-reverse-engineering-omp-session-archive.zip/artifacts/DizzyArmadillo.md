{
  "report": "/home/asdf/Downloads/ivona_re/report_voice_pack.md",
  "summary": "Wrote the voice-pack contract report (45.8 KB, sections 1-8 + 3 appendices, 13 [INFERENCE] markers). Read-only on all decompiled sources.",
  "key_findings": [
    "Manifest: sharedUserId com.ivona.ttsuser + signer SHA1 64:7A:B1:77:... (verified identical cert on engine/Kendra/Amy); components: <pkg>.VoiceApp, <pkg>.IvonaVoice (MAIN/LAUNCHER), <pkg>.CheckVoiceInstalled (action com.ivona.tts.CHECK_VOICE_INSTALLED), <pkg>.UpdateReceiver, voicelib.ActivityReceiver x2 (USER_PRESENT + PACKAGE_*), voicelib.VoiceDownloaderService, plus dead .DownloadVoiceFilesService entry; no meta-data; no tts_lang categories on packs (those are on engine com.ivona.tts.Ivona).",
    "Disk: /Android/obb/<pkg>/main.<N>.<pkg>.obb + patch.199.<pkg>.obb (patch version hardcoded \"patch.199.\" in libtiver.so); VoiceFiles.a() derives voice id from Application class name, deletes legacy /sdcard/ivona/{vox,lang} files, native checkFiles==0 is the sole install verdict; libtiver gates on exact main-obb byte size from its 48-byte-stride table (Kendra 152219597, Amy 149905560 verified vs real files) and re-extracts patch zip entries to the obb dir; no checksums anywhere.",
    "Metadata/locale: engine parses package name com.ivona.tts.voicebeta.<lang3>.<country3>.<voice> into Locale(split[4],split[5],split[6]) (3-letter ISO codes + variant); libvoice string <pkg>/lib/libvoice_*.so is the voice handle; CheckVoiceInstalled wire format fully specified (XOR key, framing, extras checkVoice/checkVoiceResult) but unused by shipped engine 1.6.55.617 (0 dex hits); live handoff = IvonaGui extras VoicePackage/welcome_text/app_name/voice_info/app_icon/dont_return_to_gui, engine relaunches <pkg>/.IvonaVoice by literal component name.",
    "Download flow: Google expansion downloader + Play LVL (FILE_NAME/FILE_SIZE/FILE_URL from licensing response, no hardcoded endpoints); VoiceDownloaderService h()=RSA public key, i()=30-byte salt, j()=VoiceDwnldAlarmReceiver; alarm action android.intent.action.DOWNLOAD_WAKEUP; content-type application/vnd.android.obb; UpdateReceiver posts notification id 2 (continue_update) when post-update files mismatch; ActivityReceiver pokes engine via upkgmon + TTSServiceActivation.",
    "Kendra vs Amy: identical template - voicelib/commonlib byte-identical, manifest differs only in 4 package/class names, strings differ in exactly 7 default-locale entries (+3 pl), icons + libvoice_*.so + OBBs differ, libtiver/libttsivonavoice md5-identical (both APKs' tables already contain both voices).",
    "Config: pack ships none (no assets/res/xml; OBB = CDXV blob + lang_*.dat); engine parses its own embedded ivona_config XML (sections global/packages/voice_data/voice_lib/lex_dir) via libttsivona.so and caches ivona_pkgs.csv 'pkg;versionCode;apiVer;fstate;name;SDK'.",
    "Billing/analytics: CHECK_LICENSE used for real (LVL nonce flow, state_failed_unlicensed string); Google Analytics classes bundled but receiver unregistered and unreferenced = dead code; no BILLING permission in pack.",
    "New-pack checklist (§8): critical blocker is that libtiver.so's compiled-in table + hardcoded patch.199. must be patched for a new package, field[9] must equal exact main-obb size, and launcher class must remain <pkg>.IvonaVoice."
  ],
  "uncertainties_marked": [
    "struct stat field mapping in decompiled size check (size-equality verified, field names shifted)",
    "table field[7] and CDXV header word meanings",
    "english.lex location / ISEF header meaning",
    "how engine native getVoicesApiVersion obtains display name",
    "whether engine dlopens pack libtiver.so / isoemn() config path active",
    "original RequestCode.a() loop shape (single enum value makes it moot)"
  ],
  "sibling_coordination": "Sent TroubledSailfish a detailed libtiver findings dump (function addrs 0x16a64/0x69b8/0x66e8, 12-field table decode with verified sizes, patch.199 hardcode, stat-field ambiguity) for folding into report_libtiver.md.",
  "checks_for_main": [
    "grep -c DownloadVoiceFiles out/jadx_kendra/resources/classes.dex  # expect 0 (dead manifest entry)",
    "diff -rq out/jadx_kendra/sources/com/ivona/tts/voicelib out/jadx_amy/sources/com/ivona/tts/voicelib  # expect silent",
    "grep -ao 'checkVoice\\|CHECK_VOICE_INSTALLED' out/tts/classes.dex  # expect 0 (protocol unused by engine)",
    "md5sum out/libs/{kendra,amy}/libtiver.so out/libs/{kendra,amy}/libttsivonavoice.so  # expect pairwise identical"
  ],
  "notes": "Overlapping libtiver internals are cross-referenced with TroubledSailfish's report_libtiver.md (they received my evidence). Engine-internal details (getVoicesApiVersion name source, ivona_config contents) were kept minimal since a sibling reads the TTS service."
}