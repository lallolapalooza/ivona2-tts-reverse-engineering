{
  "report_path": "/home/asdf/Downloads/ivona_re/report_engine_app.md",
  "status": "complete (amended after cross-agent native verification)",
  "amendment": "§5.3/§5.6/§11 uncertainty list updated after TroubledSailfish's native proof, independently re-verified by me in out/ghidra_dump/decompiled.c:10198-10290",
  "sections": [
    "1. Component map — 13 manifest components, exact names/attributes/intent actions+categories (incl. tts_lang.*), tts_engine.xml settingsActivity, permissions, sharedUserId model, cross-package reachability evidence",
    "2. Process identity — sharedUserId com.ivona.ttsuser, setEnvRuntime(\"/data/data/\", sdcard+\"/\"), same-uid explicit starts from voice APKs",
    "3. IVONATextToSpeechService lifecycle — onCreate order, CountDownLatch gate, LocalSocket 'exists' handshake, MSG_INIT create()+deferred loadLanguage, onDestroy, all language callbacks incl. bytecode-recovered onLoadLanguage normalization {l,\"\",\"\"}/{l,c,\"\"}/{l,c,v}, onSynthesizeText, threading table, onGetSampleText NOT overridden",
    "4. PCM pipeline — start(getSampleRate(),2,1), getMaxBufferSize() buffer, setProperty rate/pitch, GENERATE_MARKS/SET_CONTRAST, synthesizeText overloads, audioAvailableClbk(length,status) TTS_SYNTH_DONE=0, List-marks out-param, full JNI symbol table (nm -D)",
    "5. Discovery — getPackagesForUid, getVoicesApiVersion EXACT format apiVer;fstate;name;stamp;dataLocation (5 fields, Java uses 4) produced by dlopen <pkg>/lib/libtiver.so + dlsym v()/h() with gate struct[0]>0x13 && struct[3]>0x2f && struct[1]<3 and h() probes of <sdcard>/ivona/ then <sdcard>/Android/obb/, CSV 7-column cache, 53-entry static table, full IvonaPackagesInfo API, fstate enum, voice-pack requirements (5 items)",
    "6. Config — ConfigXMLDataSet native-only, /etc/ivona/ivona_config.xml, ivona_config/global/packages, voice_data/voice_lib/lex_dir, complete settings-key table",
    "7. Settings UI — EngineSettings ListPreference keys/defaults/file persistence, ivona_custom.emailSet, ivona_referrer.referrer, .android_version, CustomSettings/Service extras, receivers",
    "8. Download/license — gw.ivona.com/android/trial POST (d,u,b,v,vc,c) + salted SHA-256 proof construction, mobile.ivona.com URLs, WelcomeActivity campaign ids, billing (permission only)",
    "9. Endpoints/crypto/protocol — 5 URLs, SHA-256 salt, 64-byte XOR key + 48-byte trailing key, LocalServerSocket bytes 0xBB/0x38/0x0B2F14 exists/close, TTSMessage layout",
    "10. com.google.tts — 4 AIDL descriptors with transaction numbers, no implementing service in APK, bind actions START_TTS_SERVICE_BETA+TTS_BETA / USE_TTS+TTS, forwarding only via platform TextToSpeech super.* fallback (TTS_SERVICE), dead TextToSpeechSettings reference",
    "11. com.google.android.apps.analytics — INSTALL_REFERRER → google_analytics.db, no endpoint/UA id, receiver unregistered ⇒ dead",
    "12. Reimplementation checklist + uncertainty markers"
  ],
  "uncertainties": [
    "[INFERENCE] isoemn() == presence of /etc/ivona/ivona_config.xml",
    "[INFERENCE] concrete file names under the now-confirmed data roots and the com.ivona.tts/files/.<lang>_<ctry> join",
    "[INFERENCE] marks List element type",
    "[UNCERTAIN] GetSampleText unconditional tail setResult(-2, \"\")",
    "[INFERENCE] sender of encrypted activation-socket messages",
    "getSampleRate() value native-determined"
  ],
  "files_modified": [
    "/home/asdf/Downloads/ivona_re/report_engine_app.md"
  ]
}