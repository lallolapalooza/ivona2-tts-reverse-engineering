{
  "status": "complete",
  "confirmed_by_second_party": true,
  "summary": "Cleaned up the last two pipeline-level deviations. (1) Codec swap: refimpl/tts.py now uses the clean-room stdlib-only codec_spec.Spec, the Hamming-sinc resampler is gone (codec_parts Resampler handles 24k->22.05k), Unicorn is off the runtime path (segment_unit lazy import); found+fixed a real missing per-window Spec reset. (2) Punctuation spoken by name via the plug-in's full 200-name table (scripts/symbol_names.py); chains match the oracle position-wise (ref_default 26/26, ref_nopunct 19/19). (3) Final A/B on the current tree: ref_nopunct +47.66 ms / lag -220 ms / corr 0.6412 / 50.6% within 3 dB; ref_default -25.58 ms / lag +20 ms / corr 0.6300 / 47.7%. Plumbing and (post-rewire) selection are exact; the residual is the waveform stage's per-unit window/duration handling (FUN_00062d14). Reports: report_pipeline.md §11, REPLICATION_STATUS.md §4 causes 6-7 + audio row.",
  "files_new": [
    "scripts/symbol_names.py",
    "scripts/verify_codec_swap.py"
  ],
  "files_changed": [
    "refimpl/tts.py",
    "scripts/codec_spec.py",
    "scripts/segment_unit.py",
    "out/tts_demo/*",
    "report_pipeline.md",
    "REPLICATION_STATUS.md"
  ]
}