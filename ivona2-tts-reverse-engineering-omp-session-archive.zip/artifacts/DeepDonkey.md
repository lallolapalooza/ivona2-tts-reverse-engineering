{
  "status": "complete",
  "deliverables": {
    "dir": "/home/asdf/Downloads/ivona_re/refimpl/",
    "files": [
      "cdxv.py",
      "voices.py",
      "license.py",
      "marks.py",
      "params.py",
      "test_conformance.py",
      "README.md",
      "report_refimpl.md (at repo root)"
    ],
    "originals": "read-only; only refimpl/ and report_refimpl.md added"
  },
  "acceptance": {
    "command": "python3 -m unittest discover -s refimpl",
    "result": "Ran 74 tests in 8.696s — OK (exit 0)",
    "coverage": "every test runs against real artifacts and cites the report section it encodes"
  },
  "modules": {
    "cdxv.py": "CDXV reader: 104-byte header, index walk, sections A-E, unit records; full invariant pass on both real main.199 OBBs (N=426991/404847, 8496/8164 nulls, 1601/1772 diphones, 58/62 phonemes, len==2N+12, contiguity, windows inside gap, sum(count)==len(B)/4, len(C)==36N, B permutation, gaps stats 361352490/346537077)",
    "voices.py": "pkg grammar, getVoicesApiVersion 5-field string, ivona_pkgs.csv 7 cols, selection file .<lang3>_<country3>, probe order ivona/ then Android/obb/, main.<N>/patch.199 naming, 42-row table_full.json loader + exact size gate, v() gate (abi>0x13,stride>0x2f,apiVer<3), accessor i<=43",
    "license.py": "XOR decode (KEY=0x6d070,D=0x6d079,D2=0x6d07d) == out/certs/ivona_certificate_decoded.txt byte-for-byte (1798B); attribute parse; 520B signature",
    "marks.py": "20-byte record parse, type->TYPE_* table, GENERATE_MARKS bitmask, ownership table (0,1,1,0,1) read from libttsivonavoice.so 0x14bfc8",
    "params.py": "set|get:KEY[:min|max|def] grammar, 16-key table, errno 8/6 semantics, float-key 1..99 XOR encoding"
  },
  "notes": [
    "report discrepancy found: report_obb_format.md §11 says patch deflated 74863; real ZIP central dir stores 74683 (digits transposed). Test asserts artifact value 74683.",
    "Boundary (NOT implemented, listed in README/report): gap codec, ISEF payload, synthesis internals (SSML/Viterbi/waveform), native tts_* ABI execution, certificate signature verification, unresolved section-C bytes and unit-record Y field, open report_engine_api/libvoice items."
  ],
  "main_agent_checks": "Re-run `python3 -m unittest discover -s refimpl` (exit 0, 74 tests); optionally spot-check that no files outside refimpl/ and report_refimpl.md changed."
}